from .models import *

editorial_1 = Editorial.objects.create(
    nombre='Editorial Ejemplo'
)

libro_1 = Libro.objects.create(
    isbn='1234567890123',
    titulo='Introducción a la Programación',
    paginas=250,
    fecha_publicacion='2024-10-27',
    imagen='https://th.bing.com/th/id/R.b165f8fa8de139c95917895c4be688d0?rik=3hndkQ33N9GSQg&pid=ImgRaw&r=0',
    desc_corta='Un libro básico sobre programación para principiantes.',
    estatus='B',
    categoria='Informática',
    editorial=Editorial.objects.get(id=1)
)

libro_2 = Libro.objects.create(
    isbn='1234567890124',
    titulo='Introducción a la Programación 2',
    paginas=200,
    fecha_publicacion='2024-10-27',
    imagen='https://th.bing.com/th/id/R.b165f8fa8de139c95917895c4be688d0?rik=3hndkQ33N9GSQg&pid=ImgRaw&r=0',
    desc_corta='Un libro básico sobre programación para intermedios.',
    estatus='B',
    categoria='Informática',
    editorial=Editorial.objects.get(id=1)
)
